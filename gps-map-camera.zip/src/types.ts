/**
 * Types & Interfaces for GPS Map Camera
 */

export type CameraMode = 'photo' | 'video';
export type FlashMode = 'off' | 'on' | 'auto' | 'torch';
export type MapType = 'standard' | 'satellite' | 'terrain' | 'hybrid';
export type AltitudeUnit = 'm' | 'ft';
export type TempUnit = 'C' | 'F';

export type ResolutionPreset = '480p' | '720p' | '1080p' | '4K';
export type StampPosition = 'bottom-left' | 'bottom-center' | 'bottom-right' | 'top-left' | 'top-center' | 'top-right';
export type StampSize = 'small' | 'medium' | 'large' | 'xlarge';
export type FontWeight = 'normal' | 'bold' | 'heavy';
export type StampTextColor = 'emerald' | 'white' | 'yellow' | 'cyan' | 'orange' | 'lime';

export interface StampSettings {
  brandingTitle: string;
  brandingTagline: string;
  mapType: MapType;
  zoomLevel: number;
  showMapTile: boolean;
  showLatLng: boolean;
  showAltitude: boolean;
  showAddress: boolean;
  showDateTime: boolean;
  showWeather: boolean;
  showCompass: boolean;
  altitudeUnit: AltitudeUnit;
  tempUnit: TempUnit;
  shutterSound: boolean;

  // Image & Video Resolution Settings
  photoResolution: ResolutionPreset;
  videoResolution: ResolutionPreset;

  // Stamp Size & Position Settings
  stampSize: StampSize;
  stampPosition: StampPosition;

  // Stamp Typography, Colors & Transparency Settings
  fontSizeScale: number;
  fontWeight: FontWeight;
  textColor: StampTextColor;
  backgroundOpacity: number;
}

export interface GPSData {
  lat: number;
  lng: number;
  accuracy: number;
  altitude: number | null;
  heading: number | null;
  speed: number | null;
  address: string;
  weather: {
    tempC: number;
    tempF: number;
    condition: string;
  };
  status: 'active' | 'weak' | 'searching' | 'error';
  timestamp: number;
}

export interface MediaItem {
  id: string;
  type: 'photo' | 'video';
  uri: string;
  filePath?: string;
  name: string;
  timestamp: number;
  size: number;
  lat: number;
  lng: number;
  address: string;
  duration?: number; // Video duration in seconds
}

export interface CameraState {
  facingMode: 'user' | 'environment';
  flashMode: FlashMode;
  mode: CameraMode;
  isRecording: boolean;
  recordingTime: number;
  hasTorch: boolean;
  zoom: number;
  error: string | null;
}
