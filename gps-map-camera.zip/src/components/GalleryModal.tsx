import React, { useState } from 'react';
import { X, Trash2, Download, Video, MapPin, Calendar, HardDrive, Play } from 'lucide-react';
import { MediaItem } from '../types';

interface GalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: MediaItem[];
  onDeleteItem: (id: string) => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({
  isOpen,
  onClose,
  items,
  onDeleteItem,
}) => {
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);

  if (!isOpen) return null;

  const handleDownload = (item: MediaItem) => {
    const a = document.createElement('a');
    a.href = item.uri;
    a.download = item.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col text-slate-100 no-select">
      {/* Top Header */}
      <header className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <span>In-App Media Gallery</span>
            <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
              {items.length} Items
            </span>
          </h2>
          <p className="text-xs text-slate-400">Pictures/GPS_Map_Camera</p>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
        {items.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
            <Video className="w-16 h-16 stroke-1 mb-3 text-slate-600 animate-pulse" />
            <p className="text-base font-semibold text-slate-400">No media captured yet</p>
            <p className="text-xs text-slate-500 mt-1">
              Photos and videos captured with GPS stamp will appear here.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {items.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className="group relative aspect-square bg-slate-900 rounded-xl overflow-hidden border border-slate-800 hover:border-emerald-500/80 cursor-pointer transition-all shadow-md"
              >
                {item.type === 'video' ? (
                  <div className="w-full h-full bg-slate-950 relative flex items-center justify-center">
                    <video src={item.uri} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center">
                      <div className="p-2.5 rounded-full bg-rose-600/90 text-white shadow-lg group-hover:scale-110 transition-transform">
                        <Play className="w-5 h-5 fill-white ml-0.5" />
                      </div>
                    </div>
                  </div>
                ) : (
                  <img
                    src={item.uri}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                )}

                {/* Badge Overlay */}
                <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-950/80 text-emerald-400 border border-slate-700 backdrop-blur-sm">
                  {item.type.toUpperCase()}
                </div>

                <div className="absolute bottom-0 inset-x-0 p-2 bg-gradient-to-t from-slate-950/90 to-transparent text-[10px] text-slate-300 truncate">
                  {new Date(item.timestamp).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox Modal for Selected Item */}
      {selectedItem && (
        <div className="fixed inset-0 z-60 bg-slate-950/95 backdrop-blur-lg flex flex-col justify-between p-4">
          {/* Lightbox Header */}
          <div className="flex items-center justify-between z-10">
            <div>
              <p className="text-sm font-bold text-white">{selectedItem.name}</p>
              <p className="text-xs text-slate-400">
                {new Date(selectedItem.timestamp).toLocaleString()}
              </p>
            </div>
            <button
              onClick={() => setSelectedItem(null)}
              className="p-2 rounded-full hover:bg-slate-800 text-slate-300 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Lightbox Media Viewer */}
          <div className="flex-1 flex items-center justify-center my-4 overflow-hidden">
            {selectedItem.type === 'video' ? (
              <video
                src={selectedItem.uri}
                controls
                autoPlay
                className="max-h-full max-w-full rounded-xl border border-slate-800 shadow-2xl object-contain"
              />
            ) : (
              <img
                src={selectedItem.uri}
                alt={selectedItem.name}
                className="max-h-full max-w-full rounded-xl border border-slate-800 shadow-2xl object-contain"
              />
            )}
          </div>

          {/* Lightbox Metadata Footer & Action Buttons */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 backdrop-blur-md space-y-3">
            {/* Location & Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-1.5 text-slate-200">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-mono text-emerald-300">
                  {selectedItem.lat.toFixed(6)}°, {selectedItem.lng.toFixed(6)}°
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-300 truncate">
                <Calendar className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="truncate">{selectedItem.address}</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-400">
                <HardDrive className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Size: {formatSize(selectedItem.size)}</span>
              </div>
            </div>

            {/* Actions Bar */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => handleDownload(selectedItem)}
                className="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-md"
              >
                <Download className="w-4 h-4" />
                <span>Save / Download</span>
              </button>
              <button
                onClick={() => {
                  onDeleteItem(selectedItem.id);
                  setSelectedItem(null);
                }}
                className="bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
