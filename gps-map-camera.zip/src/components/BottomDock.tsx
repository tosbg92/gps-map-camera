import React from 'react';
import { Camera, Video, RefreshCw, Square, Zap, ZapOff, Menu, Image as ImageIcon } from 'lucide-react';
import { CameraMode, FlashMode, MediaItem } from '../types';

interface BottomDockProps {
  mode: CameraMode;
  flashMode: FlashMode;
  onChangeMode: (mode: CameraMode) => void;
  onShutterPress: () => void;
  onFlipCamera: () => void;
  onToggleFlash: () => void;
  onOpenGallery: () => void;
  onOpenSettings: () => void;
  lastMediaItem: MediaItem | null;
  totalMediaCount: number;
  isRecording: boolean;
  recordingTime: number;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  mode,
  flashMode,
  onChangeMode,
  onShutterPress,
  onFlipCamera,
  onToggleFlash,
  onOpenGallery,
  onOpenSettings,
  lastMediaItem,
  totalMediaCount,
  isRecording,
  recordingTime,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="absolute bottom-0 left-0 right-0 z-20 pb-5 pt-3 px-3 sm:px-6 bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent flex flex-col items-center gap-3 no-select">
      {/* Recording Duration Indicator in Video Mode */}
      {isRecording && (
        <div className="bg-rose-600/90 text-white text-xs font-mono font-bold px-3 py-1 rounded-full border border-rose-400 flex items-center gap-2 shadow-lg record-pulse">
          <span className="w-2 h-2 rounded-full bg-white animate-ping" />
          <span>REC {formatTime(recordingTime)}</span>
        </div>
      )}

      {/* Mode Switcher Pill Tabs */}
      {!isRecording && (
        <div className="bg-slate-900/80 p-1 rounded-full border border-slate-800 backdrop-blur-md flex items-center gap-1 shadow-lg">
          <button
            onClick={() => onChangeMode('photo')}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
              mode === 'photo'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>PHOTO</span>
          </button>
          <button
            onClick={() => onChangeMode('video')}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
              mode === 'video'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>VIDEO</span>
          </button>
        </div>
      )}

      {/* Bottom Main Controls Row */}
      <div className="w-full max-w-md flex items-center justify-between px-2 sm:px-4">
        {/* 1. Main Menu Button */}
        <button
          onClick={onOpenSettings}
          title="Menu / Settings"
          className="w-12 h-12 rounded-2xl bg-slate-900/90 border border-slate-700/80 flex items-center justify-center text-slate-200 hover:bg-slate-800 active:scale-90 transition-all shadow-md shrink-0"
        >
          <Menu className="w-5 h-5 text-emerald-400" />
        </button>

        {/* 2. Gallery Shortcut Button */}
        <button
          onClick={onOpenGallery}
          title="Gallery"
          className="relative w-12 h-12 rounded-2xl bg-slate-900/90 border border-slate-700/80 overflow-hidden flex items-center justify-center active:scale-90 transition-all shadow-md group shrink-0"
        >
          {lastMediaItem ? (
            <img
              src={lastMediaItem.uri}
              alt="Last captured"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
          ) : (
            <ImageIcon className="w-5 h-5 text-emerald-400" />
          )}

          {totalMediaCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-emerald-500 text-slate-950 font-black text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-950 shadow-md">
              {totalMediaCount > 99 ? '99+' : totalMediaCount}
            </span>
          )}
        </button>

        {/* 3. Center Main Shutter Button */}
        <button
          onClick={onShutterPress}
          className={`relative w-20 h-20 rounded-full border-4 border-white/90 p-1 flex items-center justify-center transition-all active:scale-90 shadow-[0_0_20px_rgba(0,0,0,0.5)] shrink-0 ${
            mode === 'video' ? 'hover:border-rose-400' : 'hover:border-emerald-400'
          }`}
        >
          {mode === 'photo' ? (
            <div className="w-full h-full rounded-full bg-white hover:bg-slate-100 active:bg-emerald-400 transition-colors shadow-inner" />
          ) : isRecording ? (
            <div className="w-9 h-9 rounded-md bg-rose-600 flex items-center justify-center record-pulse">
              <Square className="w-5 h-5 fill-white text-white" />
            </div>
          ) : (
            <div className="w-full h-full rounded-full bg-rose-600 hover:bg-rose-500 transition-colors flex items-center justify-center">
              <span className="w-5 h-5 rounded-full bg-white/20" />
            </div>
          )}
        </button>

        {/* 4. Flashlight Toggle Button */}
        <button
          onClick={onToggleFlash}
          title={`Flash: ${flashMode.toUpperCase()}`}
          className={`w-12 h-12 rounded-2xl border flex items-center justify-center active:scale-90 transition-all shadow-md shrink-0 ${
            flashMode === 'on' || flashMode === 'torch'
              ? 'bg-amber-500/20 border-amber-400/80 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
              : 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:bg-slate-800'
          }`}
        >
          {flashMode === 'on' || flashMode === 'torch' ? (
            <Zap className="w-5 h-5 fill-amber-400 text-amber-400" />
          ) : (
            <ZapOff className="w-5 h-5 text-slate-400" />
          )}
        </button>

        {/* 5. Camera Flip / Rotate Button */}
        <button
          onClick={onFlipCamera}
          title="Rotate Camera"
          className="w-12 h-12 rounded-2xl bg-slate-900/90 border border-slate-700/80 flex items-center justify-center text-slate-200 active:scale-90 transition-all hover:bg-slate-800 shadow-md shrink-0"
        >
          <RefreshCw className="w-5 h-5 text-emerald-400" />
        </button>
      </div>
    </div>
  );
};
