import React, { useEffect, useState } from 'react';
import { MapPin, Navigation, Compass, Thermometer } from 'lucide-react';
import { GPSData, StampSettings, StampPosition, StampTextColor, StampSize, FontWeight } from '../types';
import { getMapTileUrl } from '../utils/stamp';

interface LiveStampOverlayProps {
  gps: GPSData;
  settings: StampSettings;
}

const COLOR_CLASSES: Record<StampTextColor, { text: string; border: string; bar: string }> = {
  emerald: { text: 'text-emerald-400', border: 'border-emerald-500/50', bar: 'from-emerald-500 via-teal-400 to-emerald-500' },
  white: { text: 'text-white', border: 'border-white/50', bar: 'from-white via-slate-200 to-white' },
  yellow: { text: 'text-yellow-400', border: 'border-yellow-500/50', bar: 'from-yellow-400 via-amber-300 to-yellow-400' },
  cyan: { text: 'text-cyan-400', border: 'border-cyan-500/50', bar: 'from-cyan-400 via-sky-300 to-cyan-400' },
  orange: { text: 'text-orange-400', border: 'border-orange-500/50', bar: 'from-orange-400 via-amber-400 to-orange-400' },
  lime: { text: 'text-lime-400', border: 'border-lime-500/50', bar: 'from-lime-400 via-emerald-400 to-lime-400' },
};

const STAMP_SIZE_SCALE: Record<StampSize, number> = {
  small: 0.85,
  medium: 1.0,
  large: 1.18,
  xlarge: 1.35,
};

const FONT_WEIGHT_CLASSES: Record<FontWeight, string> = {
  normal: 'font-normal',
  bold: 'font-bold',
  heavy: 'font-black',
};

export const LiveStampOverlay: React.FC<LiveStampOverlayProps> = ({ gps, settings }) => {
  const [mapTileUrl, setMapTileUrl] = useState<string>('');
  const [tileError, setTileError] = useState(false);

  useEffect(() => {
    if (settings.showMapTile) {
      setTileError(false);
      const url = getMapTileUrl(gps.lat, gps.lng, settings.zoomLevel, settings.mapType);
      setMapTileUrl(url);
    }
  }, [gps.lat, gps.lng, settings.zoomLevel, settings.mapType, settings.showMapTile]);

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const timeStr = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const getPositionClasses = (position: StampPosition) => {
    switch (position) {
      case 'top-left':
        return 'top-4 left-3 right-auto max-w-sm';
      case 'top-center':
        return 'top-4 left-3 right-3 sm:left-1/2 sm:-translate-x-1/2 sm:max-w-md';
      case 'top-right':
        return 'top-4 right-3 left-auto max-w-sm';
      case 'bottom-center':
        return 'bottom-24 left-3 right-3 sm:left-1/2 sm:-translate-x-1/2 sm:max-w-md';
      case 'bottom-right':
        return 'bottom-24 right-3 left-auto max-w-sm';
      case 'bottom-left':
      default:
        return 'bottom-24 left-3 right-auto max-w-sm';
    }
  };

  const colors = COLOR_CLASSES[settings.textColor] || COLOR_CLASSES.emerald;
  const sizeScale = (STAMP_SIZE_SCALE[settings.stampSize] || 1.0) * (settings.fontSizeScale || 1.0);
  const fontWeightClass = FONT_WEIGHT_CLASSES[settings.fontWeight] || 'font-bold';
  const bgOpacity = settings.backgroundOpacity ?? 0.85;

  return (
    <div
      className={`absolute z-10 pointer-events-none no-select transition-all ${getPositionClasses(
        settings.stampPosition
      )}`}
      style={{
        transform: `scale(${sizeScale})`,
        transformOrigin: settings.stampPosition?.startsWith('top')
          ? settings.stampPosition.includes('right')
            ? 'top right'
            : settings.stampPosition.includes('center')
            ? 'top center'
            : 'top left'
          : settings.stampPosition?.includes('right')
          ? 'bottom right'
          : settings.stampPosition?.includes('center')
          ? 'bottom center'
          : 'bottom left',
      }}
    >
      <div
        className={`glass-card rounded-xl p-3 border shadow-2xl backdrop-blur-md text-white transition-all ${colors.border}`}
        style={{
          backgroundColor: `rgba(2, 6, 23, ${bgOpacity})`,
        }}
      >
        {/* Top Accent Bar */}
        <div className={`h-0.5 bg-gradient-to-r ${colors.bar} rounded-t-xl mb-2.5`} />

        <div className="flex gap-3 items-center">
          {/* Left: Mini OSM Map Preview Box */}
          {settings.showMapTile && (
            <div className={`relative w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden border-2 bg-slate-900 shrink-0 shadow-inner ${colors.border}`}>
              {mapTileUrl && !tileError ? (
                <img
                  src={mapTileUrl}
                  alt="Map Tile Preview"
                  className="w-full h-full object-cover"
                  onError={() => setTileError(true)}
                />
              ) : (
                <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center p-1 text-[10px] text-slate-400">
                  <Navigation className={`w-5 h-5 mb-0.5 animate-bounce ${colors.text}`} />
                  <span>Map Tile</span>
                </div>
              )}

              {/* Center Location Pin */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-600 border border-white" />
                </span>
              </div>
            </div>
          )}

          {/* Right: Detailed Live Overlay Metadata */}
          <div className="flex-1 min-w-0 space-y-1">
            {/* Branding Header (only if provided) */}
            {(settings.brandingTitle || settings.brandingTagline) && (
              <div className="flex items-center gap-1.5 flex-wrap">
                {settings.brandingTitle && (
                  <span className={`text-sm tracking-tight truncate ${colors.text} ${fontWeightClass}`}>
                    {settings.brandingTitle}
                  </span>
                )}
                {settings.brandingTagline && (
                  <span className="text-[10px] text-slate-300 italic opacity-80 truncate">
                    [{settings.brandingTagline}]
                  </span>
                )}
              </div>
            )}

            {/* Latitude & Longitude */}
            {settings.showLatLng && (
              <div className="text-[11px] sm:text-xs text-slate-100 flex items-center gap-1">
                <MapPin className={`w-3 h-3 shrink-0 ${colors.text}`} />
                <span className={`font-mono ${fontWeightClass}`}>
                  {gps.lat.toFixed(6)}°, {gps.lng.toFixed(6)}°
                </span>
                <span className="text-[10px] text-slate-400 font-normal">
                  (±{Math.round(gps.accuracy)}m)
                </span>
              </div>
            )}

            {/* Address & Altitude */}
            {(settings.showAddress || settings.showAltitude) && (
              <div className="text-[11px] text-slate-300 font-normal line-clamp-2 leading-tight">
                {settings.showAltitude && gps.altitude !== null && (
                  <span className={`font-medium mr-1.5 ${colors.text}`}>
                    Alt:{' '}
                    {settings.altitudeUnit === 'ft'
                      ? `${Math.round(gps.altitude * 3.28084)} ft`
                      : `${Math.round(gps.altitude)} m`}
                  </span>
                )}
                {settings.showAddress && (
                  <span className="opacity-90">{gps.address}</span>
                )}
              </div>
            )}

            {/* Date, Time, Weather & Compass */}
            <div className="text-[10px] text-slate-400 flex flex-wrap items-center gap-x-2 gap-y-0.5 pt-0.5 border-t border-slate-800/80">
              {settings.showDateTime && (
                <span>
                  {dateStr} • {timeStr}
                </span>
              )}

              {settings.showWeather && (
                <span className="flex items-center gap-0.5 text-amber-300">
                  <Thermometer className="w-2.5 h-2.5" />
                  {settings.tempUnit === 'F' ? `${gps.weather.tempF}°F` : `${gps.weather.tempC}°C`}
                </span>
              )}

              {settings.showCompass && gps.heading !== null && (
                <span className="flex items-center gap-0.5 text-cyan-300">
                  <Compass className="w-2.5 h-2.5" />
                  {Math.round(gps.heading)}°
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
