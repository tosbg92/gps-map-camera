import React from 'react';
import { X, Map, Layers, Type, Volume2, HardDrive, RotateCcw, Check, Sliders, Video, Camera, Layout, Palette } from 'lucide-react';
import { MapType, ResolutionPreset, StampPosition, StampSize, StampTextColor, FontWeight, StampSettings } from '../types';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  settings: StampSettings;
  onUpdateSettings: (newSettings: StampSettings) => void;
  onResetSettings: () => void;
  onClearCache: () => void;
}

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetSettings,
  onClearCache,
}) => {
  if (!isOpen) return null;

  const handleChange = <K extends keyof StampSettings>(key: K, value: StampSettings[K]) => {
    onUpdateSettings({
      ...settings,
      [key]: value,
    });
  };

  const mapTypes: { id: MapType; label: string }[] = [
    { id: 'standard', label: 'Standard' },
    { id: 'satellite', label: 'Satellite' },
    { id: 'terrain', label: 'Terrain' },
    { id: 'hybrid', label: 'Hybrid' },
  ];

  const resolutionPresets: { id: ResolutionPreset; label: string }[] = [
    { id: '480p', label: 'SD (480p)' },
    { id: '720p', label: 'HD (720p)' },
    { id: '1080p', label: 'FHD (1080p)' },
    { id: '4K', label: 'UHD (4K)' },
  ];

  const stampPositions: { id: StampPosition; label: string }[] = [
    { id: 'bottom-left', label: 'Bottom Left' },
    { id: 'bottom-center', label: 'Bottom Center' },
    { id: 'bottom-right', label: 'Bottom Right' },
    { id: 'top-left', label: 'Top Left' },
    { id: 'top-center', label: 'Top Center' },
    { id: 'top-right', label: 'Top Right' },
  ];

  const stampSizes: { id: StampSize; label: string }[] = [
    { id: 'small', label: 'Small' },
    { id: 'medium', label: 'Medium' },
    { id: 'large', label: 'Large' },
    { id: 'xlarge', label: 'X-Large' },
  ];

  const fontWeights: { id: FontWeight; label: string }[] = [
    { id: 'normal', label: 'Normal' },
    { id: 'bold', label: 'Bold' },
    { id: 'heavy', label: 'Heavy' },
  ];

  const textColors: { id: StampTextColor; label: string; colorBg: string }[] = [
    { id: 'emerald', label: 'Emerald', colorBg: 'bg-emerald-400' },
    { id: 'white', label: 'White', colorBg: 'bg-white' },
    { id: 'yellow', label: 'Yellow', colorBg: 'bg-yellow-400' },
    { id: 'cyan', label: 'Cyan', colorBg: 'bg-cyan-400' },
    { id: 'orange', label: 'Orange', colorBg: 'bg-orange-400' },
    { id: 'lime', label: 'Lime', colorBg: 'bg-lime-400' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end no-select">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
      />

      {/* Main Slide-over Content Drawer */}
      <div className="relative w-full max-w-md bg-slate-900 border-l border-slate-800 text-slate-100 h-full flex flex-col shadow-2xl z-10 overflow-hidden">
        {/* Drawer Header */}
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white tracking-wide">Main Settings</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Settings Form */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
          {/* Section 1: Resolution Settings */}
          <section className="space-y-3 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <Camera className="w-4 h-4" />
              <span>1. Image & Video Resolution</span>
            </div>

            {/* Photo Resolution */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Photo Resolution Preset
              </label>
              <div className="grid grid-cols-2 gap-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800">
                {resolutionPresets.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => handleChange('photoResolution', r.id)}
                    className={`py-1.5 px-2 rounded-md text-xs font-semibold transition-all ${
                      settings.photoResolution === r.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Video Resolution */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Video Recording Resolution
              </label>
              <div className="grid grid-cols-2 gap-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800">
                {resolutionPresets.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => handleChange('videoResolution', r.id)}
                    className={`py-1.5 px-2 rounded-md text-xs font-semibold transition-all ${
                      settings.videoResolution === r.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>
          </section>

          {/* Section 2: Stamp Customization & Styling */}
          <section className="space-y-3.5 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <Palette className="w-4 h-4" />
              <span>2. Stamp Styling & Size</span>
            </div>

            {/* Stamp Size */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Stamp Box Size
              </label>
              <div className="grid grid-cols-4 gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                {stampSizes.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleChange('stampSize', s.id)}
                    className={`py-1.5 rounded-md text-xs font-semibold transition-all ${
                      settings.stampSize === s.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Stamp Position */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Stamp Position on Screen
              </label>
              <div className="grid grid-cols-3 gap-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800">
                {stampPositions.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleChange('stampPosition', p.id)}
                    className={`py-1.5 px-1 rounded-md text-[11px] font-semibold transition-all text-center ${
                      settings.stampPosition === p.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Font Weight */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Stamp Text Font Weight
              </label>
              <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                {fontWeights.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => handleChange('fontWeight', w.id)}
                    className={`py-1.5 rounded-md text-xs font-semibold transition-all ${
                      settings.fontWeight === w.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {w.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Primary Text Color */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Primary Header & Icon Accent Color
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {textColors.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => handleChange('textColor', c.id)}
                    className={`flex items-center gap-2 py-1.5 px-2 rounded-lg border text-xs font-medium transition-all ${
                      settings.textColor === c.id
                        ? 'border-emerald-400 bg-slate-800 text-white'
                        : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className={`w-3 h-3 rounded-full ${c.colorBg} shrink-0`} />
                    <span className="truncate">{c.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Stamp Background Opacity / Transparency Slider */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="font-semibold text-slate-300">Background Opacity</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {Math.round(settings.backgroundOpacity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0.2}
                max={1.0}
                step={0.05}
                value={settings.backgroundOpacity}
                onChange={(e) => handleChange('backgroundOpacity', Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
          </section>

          {/* Section 3: Branding & Header Text */}
          <section className="space-y-3 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <Type className="w-4 h-4" />
              <span>3. Branding Customization</span>
            </div>

            <div className="space-y-2">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Institute / Company Subtitle
                </label>
                <input
                  type="text"
                  value={settings.brandingTitle}
                  onChange={(e) => handleChange('brandingTitle', e.target.value)}
                  placeholder="e.g., SME Govt. ITI Mohammadi"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Watermark Tagline
                </label>
                <input
                  type="text"
                  value={settings.brandingTagline}
                  onChange={(e) => handleChange('brandingTagline', e.target.value)}
                  placeholder="e.g., GPS Photo by Sonu"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </section>

          {/* Section 4: Map & Tile Settings */}
          <section className="space-y-3 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <Map className="w-4 h-4" />
              <span>4. Map & Tile Settings</span>
            </div>

            {/* Map Type Tabs */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                Map Layer Type
              </label>
              <div className="grid grid-cols-2 gap-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800">
                {mapTypes.map((mt) => (
                  <button
                    key={mt.id}
                    onClick={() => handleChange('mapType', mt.id)}
                    className={`py-1.5 px-2 rounded-md text-xs font-semibold transition-all ${
                      settings.mapType === mt.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Zoom Slider */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="font-semibold text-slate-300">Map Zoom Level</span>
                <span className="font-mono text-emerald-400 font-bold">{settings.zoomLevel}x</span>
              </div>
              <input
                type="range"
                min={12}
                max={18}
                step={1}
                value={settings.zoomLevel}
                onChange={(e) => handleChange('zoomLevel', Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            {/* Show Map Tile Toggle */}
            <label className="flex items-center justify-between py-1 cursor-pointer">
              <span className="text-xs font-medium text-slate-200">Show Corner Map Tile</span>
              <input
                type="checkbox"
                checked={settings.showMapTile}
                onChange={(e) => handleChange('showMapTile', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </label>
          </section>

          {/* Section 5: Stamp Overlay Options */}
          <section className="space-y-2.5 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-1">
              <Layers className="w-4 h-4" />
              <span>5. Stamp Field Overlay Toggles</span>
            </div>

            {[
              { key: 'showLatLng', label: 'Latitude & Longitude' },
              { key: 'showAltitude', label: 'Altitude (AMSL)' },
              { key: 'showAddress', label: 'Reverse Geocoded Address' },
              { key: 'showDateTime', label: 'Date & Time Stamp' },
              { key: 'showWeather', label: 'Weather & Temperature' },
              { key: 'showCompass', label: 'Compass / Bearing Direction' },
            ].map(({ key, label }) => (
              <label
                key={key}
                className="flex items-center justify-between py-1 hover:bg-slate-900/50 px-2 rounded cursor-pointer"
              >
                <span className="text-xs font-medium text-slate-200">{label}</span>
                <input
                  type="checkbox"
                  checked={settings[key as keyof StampSettings] as boolean}
                  onChange={(e) =>
                    handleChange(key as keyof StampSettings, e.target.checked)
                  }
                  className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                />
              </label>
            ))}
          </section>

          {/* Section 6: Units & Preferences */}
          <section className="space-y-3 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <Volume2 className="w-4 h-4" />
              <span>6. Units & Preferences</span>
            </div>

            {/* Altitude Units */}
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Altitude Unit</span>
              <div className="flex bg-slate-900 rounded-lg p-0.5 border border-slate-800">
                <button
                  onClick={() => handleChange('altitudeUnit', 'm')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                    settings.altitudeUnit === 'm' ? 'bg-emerald-600 text-white' : 'text-slate-400'
                  }`}
                >
                  Meters (m)
                </button>
                <button
                  onClick={() => handleChange('altitudeUnit', 'ft')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                    settings.altitudeUnit === 'ft' ? 'bg-emerald-600 text-white' : 'text-slate-400'
                  }`}
                >
                  Feet (ft)
                </button>
              </div>
            </div>

            {/* Temperature Units */}
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Temperature Unit</span>
              <div className="flex bg-slate-900 rounded-lg p-0.5 border border-slate-800">
                <button
                  onClick={() => handleChange('tempUnit', 'C')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                    settings.tempUnit === 'C' ? 'bg-emerald-600 text-white' : 'text-slate-400'
                  }`}
                >
                  °Celsius
                </button>
                <button
                  onClick={() => handleChange('tempUnit', 'F')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
                    settings.tempUnit === 'F' ? 'bg-emerald-600 text-white' : 'text-slate-400'
                  }`}
                >
                  °Fahrenheit
                </button>
              </div>
            </div>

            {/* Shutter Sound Toggle */}
            <label className="flex items-center justify-between py-1 cursor-pointer">
              <span className="text-xs font-medium text-slate-200">Camera Shutter Sound</span>
              <input
                type="checkbox"
                checked={settings.shutterSound}
                onChange={(e) => handleChange('shutterSound', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </label>
          </section>

          {/* Section 7: Android Storage & Maintenance */}
          <section className="space-y-3 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <HardDrive className="w-4 h-4" />
              <span>7. Storage Path & Cache</span>
            </div>

            <div className="text-xs text-slate-300 space-y-1">
              <span className="text-slate-400 block">Target Android Public Storage Path:</span>
              <code className="block bg-slate-950 p-2 rounded border border-slate-800 text-emerald-400 font-mono text-[11px] break-all">
                Pictures/GPS_Map_Camera
              </code>
            </div>

            <div className="flex gap-2 pt-1">
              <button
                onClick={onResetSettings}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-700 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Defaults</span>
              </button>
              <button
                onClick={onClearCache}
                className="flex-1 bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-300 py-2 rounded-lg text-xs font-bold transition-colors"
              >
                Clear App Cache
              </button>
            </div>
          </section>
        </div>

        {/* Drawer Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>Apply & Close</span>
          </button>
        </div>
      </div>
    </div>
  );
};
