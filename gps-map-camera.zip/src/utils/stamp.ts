import { GPSData, StampSettings } from '../types';

export const TEXT_COLORS: Record<string, string> = {
  emerald: '#4ade80',
  white: '#ffffff',
  yellow: '#facc15',
  cyan: '#22d3ee',
  orange: '#fb923c',
  lime: '#a3e635',
};

export const SIZE_SCALES: Record<string, number> = {
  small: 0.8,
  medium: 1.0,
  large: 1.25,
  xlarge: 1.5,
};

export const FONT_WEIGHTS: Record<string, string> = {
  normal: 'normal',
  bold: 'bold',
  heavy: '900',
};

/**
 * Calculates OpenStreetMap tile X/Y coordinates from lat/lng and zoom level
 */
export function latLngToTileXY(lat: number, lng: number, zoom: number): { x: number; y: number } {
  const n = Math.pow(2, zoom);
  const x = Math.floor(((lng + 180) / 360) * n);
  const latRad = (lat * Math.PI) / 180;
  const y = Math.floor(((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * n);
  return { x, y };
}

/**
 * Returns map tile URL based on map type
 */
export function getMapTileUrl(lat: number, lng: number, zoom: number, mapType: string): string {
  const { x, y } = latLngToTileXY(lat, lng, zoom);
  
  switch (mapType) {
    case 'satellite':
      return `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${zoom}/${y}/${x}`;
    case 'terrain':
      return `https://tile.opentopomap.org/${zoom}/${x}/${y}.png`;
    case 'hybrid':
      return `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${zoom}/${y}/${x}`;
    case 'standard':
    default:
      return `https://tile.openstreetmap.org/${zoom}/${x}/${y}.png`;
  }
}

/**
 * Loads an image from URL with crossOrigin anonymous, fallback on error
 */
export function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = url;
  });
}

/**
 * Draws a stylized fallback map tile on canvas if external map tiles cannot be fetched
 */
function drawFallbackMapTile(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  lat: number,
  lng: number
) {
  ctx.save();
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(x, y, width, height);

  ctx.strokeStyle = '#1e293b';
  ctx.lineWidth = 1;
  const step = 15;
  for (let gx = x; gx < x + width; gx += step) {
    ctx.beginPath();
    ctx.moveTo(gx, y);
    ctx.lineTo(gx, y + height);
    ctx.stroke();
  }
  for (let gy = y; gy < y + height; gy += step) {
    ctx.beginPath();
    ctx.moveTo(x, gy);
    ctx.lineTo(x + width, gy);
    ctx.stroke();
  }

  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(x + 10, y + height / 2);
  ctx.quadraticCurveTo(x + width / 2, y + 10, x + width - 10, y + height - 10);
  ctx.stroke();

  ctx.strokeStyle = '#22c55e';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(x + width / 2, y + height / 2, 18, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = 'rgba(34, 197, 94, 0.2)';
  ctx.beginPath();
  ctx.arc(x + width / 2, y + height / 2, 18, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.arc(x + width / 2, y + height / 2, 5, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * Helper to compute card box bounds on canvas based on position and size
 */
function computeStampBoxBounds(
  width: number,
  height: number,
  scale: number,
  settings: StampSettings
) {
  const mapTileSize = settings.showMapTile ? Math.round(140 * scale) : 0;
  const padding = Math.round(16 * scale);
  
  const boxWidth = settings.showMapTile
    ? Math.min(width - 30 * scale, Math.round(750 * scale))
    : Math.min(width - 30 * scale, Math.round(650 * scale));
    
  const boxHeight = Math.round(165 * scale);

  let boxX = Math.round(15 * scale);
  let boxY = height - boxHeight - Math.round(20 * scale);

  const pos = settings.stampPosition || 'bottom-left';

  if (pos.includes('center')) {
    boxX = Math.round((width - boxWidth) / 2);
  } else if (pos.includes('right')) {
    boxX = Math.round(width - boxWidth - 15 * scale);
  }

  if (pos.startsWith('top')) {
    boxY = Math.round(20 * scale);
  }

  return { boxX, boxY, boxWidth, boxHeight, mapTileSize, padding };
}

/**
 * Main Stamp Engine: Takes an HTMLImageElement or HTMLVideoElement and draws the GPS map overlay
 */
export async function createStampedPhoto(
  source: HTMLImageElement | HTMLVideoElement,
  gps: GPSData,
  settings: StampSettings
): Promise<string> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');

  const width = source instanceof HTMLVideoElement ? source.videoWidth || 1280 : source.naturalWidth || source.width || 1280;
  const height = source instanceof HTMLVideoElement ? source.videoHeight || 720 : source.naturalHeight || source.height || 720;

  canvas.width = width;
  canvas.height = height;

  // Layer 1: Base Media Image
  ctx.drawImage(source, 0, 0, width, height);

  // User customization scaling
  const userSizeScale = (SIZE_SCALES[settings.stampSize] || 1.0) * (settings.fontSizeScale || 1.0);
  const baseScale = Math.max(0.6, width / 1280);
  const scale = baseScale * userSizeScale;

  const primaryColor = TEXT_COLORS[settings.textColor] || '#4ade80';
  const fontWeightStr = FONT_WEIGHTS[settings.fontWeight] || 'bold';
  const bgOpacity = settings.backgroundOpacity ?? 0.85;

  const { boxX, boxY, boxWidth, boxHeight, mapTileSize, padding } = computeStampBoxBounds(width, height, scale, settings);

  ctx.save();

  // Draw Card Background
  ctx.fillStyle = `rgba(15, 23, 42, ${bgOpacity})`;
  const cornerRadius = Math.round(12 * scale);
  ctx.beginPath();
  ctx.roundRect(boxX, boxY, boxWidth, boxHeight, cornerRadius);
  ctx.fill();

  // Card Border
  ctx.strokeStyle = primaryColor;
  ctx.lineWidth = Math.max(1, Math.round(1.5 * scale));
  ctx.stroke();

  // Map Tile Box
  let textXStart = boxX + padding;
  if (settings.showMapTile && mapTileSize > 0) {
    const mapX = boxX + padding;
    const mapY = boxY + Math.round((boxHeight - mapTileSize) / 2);

    ctx.fillStyle = '#090d16';
    ctx.fillRect(mapX - 2, mapY - 2, mapTileSize + 4, mapTileSize + 4);

    let mapDrawn = false;
    try {
      const tileUrl = getMapTileUrl(gps.lat, gps.lng, settings.zoomLevel, settings.mapType);
      const mapImg = await loadImage(tileUrl);
      ctx.drawImage(mapImg, mapX, mapY, mapTileSize, mapTileSize);
      mapDrawn = true;
    } catch (tileErr) {
      console.warn('Map tile load error, using fallback canvas tile:', tileErr);
    }

    if (!mapDrawn) {
      drawFallbackMapTile(ctx, mapX, mapY, mapTileSize, mapTileSize, gps.lat, gps.lng);
    }

    ctx.strokeStyle = primaryColor;
    ctx.lineWidth = Math.max(1.5, Math.round(2 * scale));
    ctx.strokeRect(mapX, mapY, mapTileSize, mapTileSize);

    const pinX = mapX + mapTileSize / 2;
    const pinY = mapY + mapTileSize / 2;

    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(pinX, pinY, 5 * scale, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5 * scale;
    ctx.beginPath();
    ctx.arc(pinX, pinY, 5 * scale, 0, Math.PI * 2);
    ctx.stroke();

    textXStart = mapX + mapTileSize + Math.round(16 * scale);
  }

  // Text Content
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
  ctx.shadowBlur = 4;

  let currentY = boxY + Math.round(26 * scale);
  const lineGap = Math.round(22 * scale);

  // Title / Tagline
  const titleText = settings.brandingTitle.trim();
  if (titleText) {
    ctx.font = `${fontWeightStr} ${Math.round(18 * scale)}px sans-serif`;
    ctx.fillStyle = primaryColor;
    ctx.fillText(titleText, textXStart, currentY);

    if (settings.brandingTagline) {
      ctx.font = `italic ${Math.round(12 * scale)}px sans-serif`;
      ctx.fillStyle = '#e2e8f0';
      const tagText = `[ ${settings.brandingTagline.trim()} ]`;
      const titleWidth = ctx.measureText(titleText).width;
      ctx.fillText(tagText, textXStart + titleWidth + Math.round(12 * scale), currentY);
    }
    currentY += Math.round(22 * scale);
  } else if (settings.brandingTagline) {
    ctx.font = `italic ${Math.round(13 * scale)}px sans-serif`;
    ctx.fillStyle = primaryColor;
    ctx.fillText(`[ ${settings.brandingTagline.trim()} ]`, textXStart, currentY);
    currentY += Math.round(22 * scale);
  }

  // Lat / Lng
  if (settings.showLatLng) {
    ctx.font = `${fontWeightStr} ${Math.round(13 * scale)}px sans-serif`;
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(`Lat: ${gps.lat.toFixed(6)}°  |  Long: ${gps.lng.toFixed(6)}° (±${Math.round(gps.accuracy)}m)`, textXStart, currentY);
    currentY += lineGap;
  }

  // Address / Alt
  if (settings.showAddress || settings.showAltitude) {
    ctx.font = `500 ${Math.round(12 * scale)}px sans-serif`;
    ctx.fillStyle = '#cbd5e1';
    let lineParts: string[] = [];

    if (settings.showAltitude && gps.altitude !== null) {
      if (settings.altitudeUnit === 'ft') {
        lineParts.push(`Alt: ${Math.round(gps.altitude * 3.28084)} ft AMSL`);
      } else {
        lineParts.push(`Alt: ${Math.round(gps.altitude)} m AMSL`);
      }
    }

    if (settings.showAddress && gps.address) {
      lineParts.push(gps.address);
    }

    const addrLine = lineParts.join('  •  ');
    const maxWidth = boxX + boxWidth - textXStart - padding;
    let truncated = addrLine;
    while (ctx.measureText(truncated).width > maxWidth && truncated.length > 10) {
      truncated = truncated.slice(0, -4) + '...';
    }
    ctx.fillText(truncated, textXStart, currentY);
    currentY += lineGap;
  }

  // Date / Time
  if (settings.showDateTime) {
    ctx.font = `500 ${Math.round(12 * scale)}px sans-serif`;
    ctx.fillStyle = '#cbd5e1';
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    ctx.fillText(`Date: ${dateStr}  ${timeStr}`, textXStart, currentY);
    currentY += lineGap;
  }

  // Weather & Compass
  if (settings.showWeather || settings.showCompass) {
    ctx.font = `500 ${Math.round(11 * scale)}px sans-serif`;
    ctx.fillStyle = '#94a3b8';
    const parts: string[] = [];
    if (settings.showWeather && gps.weather) {
      parts.push(settings.tempUnit === 'F' ? `Temp: ${gps.weather.tempF}°F` : `Temp: ${gps.weather.tempC}°C`);
    }
    if (settings.showCompass && gps.heading !== null) {
      parts.push(`Bearing: ${Math.round(gps.heading)}°`);
    }
    if (parts.length > 0) {
      ctx.fillText(parts.join('  |  '), textXStart, currentY);
    }
  }

  ctx.restore();

  return canvas.toDataURL('image/jpeg', 0.92);
}

/**
 * Synchronous stamp overlay rendering function for live video frame recording
 */
export function drawSynchronousStampOverlay(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  gps: GPSData,
  settings: StampSettings,
  cachedTileImg?: HTMLImageElement | null
) {
  const userSizeScale = (SIZE_SCALES[settings.stampSize] || 1.0) * (settings.fontSizeScale || 1.0);
  const baseScale = Math.max(0.6, width / 1280);
  const scale = baseScale * userSizeScale;

  const primaryColor = TEXT_COLORS[settings.textColor] || '#4ade80';
  const fontWeightStr = FONT_WEIGHTS[settings.fontWeight] || 'bold';
  const bgOpacity = settings.backgroundOpacity ?? 0.85;

  const { boxX, boxY, boxWidth, boxHeight, mapTileSize, padding } = computeStampBoxBounds(width, height, scale, settings);

  ctx.save();

  // Background Box
  ctx.fillStyle = `rgba(15, 23, 42, ${bgOpacity})`;
  const cornerRadius = Math.round(12 * scale);
  ctx.beginPath();
  ctx.roundRect(boxX, boxY, boxWidth, boxHeight, cornerRadius);
  ctx.fill();

  // Card Border
  ctx.strokeStyle = primaryColor;
  ctx.lineWidth = Math.max(1, Math.round(1.5 * scale));
  ctx.stroke();

  let textXStart = boxX + padding;

  // Map tile
  if (settings.showMapTile && mapTileSize > 0) {
    const mapX = boxX + padding;
    const mapY = boxY + Math.round((boxHeight - mapTileSize) / 2);

    ctx.fillStyle = '#090d16';
    ctx.fillRect(mapX - 2, mapY - 2, mapTileSize + 4, mapTileSize + 4);

    if (cachedTileImg && cachedTileImg.complete && cachedTileImg.naturalWidth > 0) {
      try {
        ctx.drawImage(cachedTileImg, mapX, mapY, mapTileSize, mapTileSize);
      } catch (e) {
        drawFallbackMapTile(ctx, mapX, mapY, mapTileSize, mapTileSize, gps.lat, gps.lng);
      }
    } else {
      drawFallbackMapTile(ctx, mapX, mapY, mapTileSize, mapTileSize, gps.lat, gps.lng);
    }

    ctx.strokeStyle = primaryColor;
    ctx.lineWidth = Math.max(1.5, Math.round(2 * scale));
    ctx.strokeRect(mapX, mapY, mapTileSize, mapTileSize);

    const pinX = mapX + mapTileSize / 2;
    const pinY = mapY + mapTileSize / 2;

    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(pinX, pinY, 5 * scale, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5 * scale;
    ctx.beginPath();
    ctx.arc(pinX, pinY, 5 * scale, 0, Math.PI * 2);
    ctx.stroke();

    textXStart = mapX + mapTileSize + Math.round(16 * scale);
  }

  // Text content
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
  ctx.shadowBlur = 4;

  let currentY = boxY + Math.round(26 * scale);
  const lineGap = Math.round(22 * scale);

  const titleText = settings.brandingTitle.trim();
  if (titleText) {
    ctx.font = `${fontWeightStr} ${Math.round(18 * scale)}px sans-serif`;
    ctx.fillStyle = primaryColor;
    ctx.fillText(titleText, textXStart, currentY);

    if (settings.brandingTagline) {
      ctx.font = `italic ${Math.round(12 * scale)}px sans-serif`;
      ctx.fillStyle = '#e2e8f0';
      const tagText = `[ ${settings.brandingTagline.trim()} ]`;
      const titleWidth = ctx.measureText(titleText).width;
      ctx.fillText(tagText, textXStart + titleWidth + Math.round(12 * scale), currentY);
    }
    currentY += Math.round(22 * scale);
  } else if (settings.brandingTagline) {
    ctx.font = `italic ${Math.round(13 * scale)}px sans-serif`;
    ctx.fillStyle = primaryColor;
    ctx.fillText(`[ ${settings.brandingTagline.trim()} ]`, textXStart, currentY);
    currentY += Math.round(22 * scale);
  }

  // Lat / Lng
  if (settings.showLatLng) {
    ctx.font = `${fontWeightStr} ${Math.round(13 * scale)}px sans-serif`;
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(
      `Lat: ${gps.lat.toFixed(6)}°  |  Long: ${gps.lng.toFixed(6)}° (±${Math.round(gps.accuracy)}m)`,
      textXStart,
      currentY
    );
    currentY += lineGap;
  }

  // Address & Alt
  if (settings.showAddress || settings.showAltitude) {
    ctx.font = `500 ${Math.round(12 * scale)}px sans-serif`;
    ctx.fillStyle = '#cbd5e1';
    let lineParts: string[] = [];

    if (settings.showAltitude && gps.altitude !== null) {
      if (settings.altitudeUnit === 'ft') {
        lineParts.push(`Alt: ${Math.round(gps.altitude * 3.28084)} ft AMSL`);
      } else {
        lineParts.push(`Alt: ${Math.round(gps.altitude)} m AMSL`);
      }
    }

    if (settings.showAddress && gps.address) {
      lineParts.push(gps.address);
    }

    const addrLine = lineParts.join('  •  ');
    const maxWidth = boxX + boxWidth - textXStart - padding;
    let truncated = addrLine;
    while (ctx.measureText(truncated).width > maxWidth && truncated.length > 10) {
      truncated = truncated.slice(0, -4) + '...';
    }
    ctx.fillText(truncated, textXStart, currentY);
    currentY += lineGap;
  }

  // Date & Time
  if (settings.showDateTime) {
    ctx.font = `500 ${Math.round(12 * scale)}px sans-serif`;
    ctx.fillStyle = '#cbd5e1';
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    ctx.fillText(`Date: ${dateStr}  ${timeStr}`, textXStart, currentY);
    currentY += lineGap;
  }

  // Weather & Compass
  if (settings.showWeather || settings.showCompass) {
    ctx.font = `500 ${Math.round(11 * scale)}px sans-serif`;
    ctx.fillStyle = '#94a3b8';
    const parts: string[] = [];
    if (settings.showWeather && gps.weather) {
      parts.push(settings.tempUnit === 'F' ? `Temp: ${gps.weather.tempF}°F` : `Temp: ${gps.weather.tempC}°C`);
    }
    if (settings.showCompass && gps.heading !== null) {
      parts.push(`Bearing: ${Math.round(gps.heading)}°`);
    }
    if (parts.length > 0) {
      ctx.fillText(parts.join('  |  '), textXStart, currentY);
    }
  }

  ctx.restore();
}
