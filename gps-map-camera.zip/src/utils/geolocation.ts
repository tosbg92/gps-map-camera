import { GPSData } from '../types';

const DEFAULT_MOHAMMADI_GPS: GPSData = {
  lat: 28.04712,
  lng: 80.30821,
  accuracy: 4,
  altitude: 155,
  heading: 185,
  speed: 0,
  address: 'SME Govt. ITI, Mohammadi, Lakhimpur Kheri, Uttar Pradesh 262804',
  weather: {
    tempC: 31,
    tempF: 88,
    condition: 'Clear Sky',
  },
  status: 'active',
  timestamp: Date.now(),
};

/**
 * Reverse geocodes lat/lng to human readable address using Nominatim OSM API
 */
export async function reverseGeocode(lat: number, lng: number): Promise<string> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
      {
        headers: {
          'User-Agent': 'GPSMapCameraApp/1.0',
        },
        signal: controller.signal,
      }
    );
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && data.display_name) {
        // Construct concise address
        const addr = data.address || {};
        const parts = [
          addr.building || addr.amenity || addr.road || addr.suburb,
          addr.village || addr.town || addr.city || addr.county,
          addr.state,
          addr.postcode,
        ].filter(Boolean);

        return parts.length > 0 ? parts.join(', ') : data.display_name;
      }
    }
  } catch (err) {
    console.warn('Reverse geocode timeout/error, using default location address:', err);
  }

  return 'SME Govt. ITI, Mohammadi, Kheri, UP 262804';
}

/**
 * Initializes GPS Geolocation Watcher
 */
export function watchGPSLocation(
  onUpdate: (gps: GPSData) => void,
  onError?: (err: any) => void
): () => void {
  let watchId: number | null = null;
  let simulatedHeading = 180;

  // Heading gyro / orientation listener if supported
  const handleOrientation = (event: DeviceOrientationEvent) => {
    if (event.alpha !== null) {
      simulatedHeading = Math.round(360 - event.alpha);
    }
  };

  if (window.DeviceOrientationEvent) {
    window.addEventListener('deviceorientation', handleOrientation, true);
  }

  if (!navigator.geolocation) {
    onUpdate({
      ...DEFAULT_MOHAMMADI_GPS,
      status: 'weak',
      timestamp: Date.now(),
    });
    return () => {};
  }

  let lastAddress = DEFAULT_MOHAMMADI_GPS.address;
  let lastGeocodeTime = 0;

  watchId = navigator.geolocation.watchPosition(
    async (position) => {
      const { latitude, longitude, accuracy, altitude, heading, speed } = position.coords;

      // Update address periodically every 30 seconds to avoid rate limits
      const now = Date.now();
      if (now - lastGeocodeTime > 30000 || lastAddress === DEFAULT_MOHAMMADI_GPS.address) {
        lastGeocodeTime = now;
        reverseGeocode(latitude, longitude).then((addr) => {
          if (addr) lastAddress = addr;
        });
      }

      const activeStatus: GPSData['status'] = accuracy <= 15 ? 'active' : accuracy <= 50 ? 'weak' : 'searching';

      const updatedGPS: GPSData = {
        lat: latitude,
        lng: longitude,
        accuracy: Math.round(accuracy) || 4,
        altitude: altitude !== null ? Math.round(altitude) : 155,
        heading: heading !== null ? Math.round(heading) : simulatedHeading,
        speed: speed !== null ? Math.round(speed * 3.6) : 0, // km/h
        address: lastAddress,
        weather: {
          tempC: 31,
          tempF: 88,
          condition: 'Partly Cloudy',
        },
        status: activeStatus,
        timestamp: Date.now(),
      };

      onUpdate(updatedGPS);
    },
    (error) => {
      console.warn('Geolocation watch error (using fallback position):', error.message);
      if (onError) onError(error);
      onUpdate({
        ...DEFAULT_MOHAMMADI_GPS,
        status: 'weak',
        timestamp: Date.now(),
      });
    },
    {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 3000,
    }
  );

  return () => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
    }
    if (window.DeviceOrientationEvent) {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    }
  };
}
