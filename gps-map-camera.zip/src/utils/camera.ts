/**
 * Lag-Free Camera Stream Manager for Android WebView & Web
 */

import { ResolutionPreset } from '../types';

export interface StartCameraOptions {
  facingMode: 'user' | 'environment';
  mode: 'photo' | 'video';
  resolution?: ResolutionPreset;
  videoElement: HTMLVideoElement;
  currentStream?: MediaStream | null;
}

export interface CameraStreamResult {
  stream: MediaStream;
  hasAudio: boolean;
  hasTorch: boolean;
}

/**
 * Cleanly stops all tracks on a MediaStream and detaches from video element
 */
export function stopCameraStream(stream: MediaStream | null | undefined, videoElement?: HTMLVideoElement | null): void {
  if (stream) {
    stream.getTracks().forEach((track) => {
      try {
        track.stop();
      } catch (e) {
        console.warn('Error stopping track:', e);
      }
    });
  }
  if (videoElement) {
    videoElement.srcObject = null;
  }
}

/**
 * Buffer delay promise helper
 */
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Initializes or switches camera stream with robust error handling and mode switching
 */
export async function startCameraStream(options: StartCameraOptions): Promise<CameraStreamResult> {
  const { facingMode, mode, resolution, videoElement, currentStream } = options;

  // Step 1: Stop existing tracks and detach
  stopCameraStream(currentStream, videoElement);

  // Step 2: Mandatory 200ms delay for Android hardware camera lock release
  await delay(200);

  const resMap: Record<ResolutionPreset, { width: number; height: number }> = {
    '480p': { width: 854, height: 480 },
    '720p': { width: 1280, height: 720 },
    '1080p': { width: 1920, height: 1080 },
    '4K': { width: 3840, height: 2160 },
  };

  const targetRes = resMap[resolution || '1080p'];

  const videoConstraints: MediaTrackConstraints = {
    facingMode: { ideal: facingMode },
    width: { ideal: targetRes.width, max: 3840 },
    height: { ideal: targetRes.height, max: 2160 },
    frameRate: { ideal: 30, max: 60 },
  };

  let newStream: MediaStream | null = null;
  let hasAudio = false;
  let retryCount = 0;
  const maxRetries = 3;

  // Try fetching stream with exponential backoff on busy device locks
  while (retryCount <= maxRetries) {
    try {
      if (mode === 'video') {
        // Attempt with audio first
        try {
          newStream = await navigator.mediaDevices.getUserMedia({
            video: videoConstraints,
            audio: true,
          });
          hasAudio = true;
        } catch (audioErr) {
          console.warn('Audio stream failed or permission denied, falling back to video only:', audioErr);
          // Fallback to video only without throwing screen-locking permission overlay
          newStream = await navigator.mediaDevices.getUserMedia({
            video: videoConstraints,
            audio: false,
          });
          hasAudio = false;
        }
      } else {
        newStream = await navigator.mediaDevices.getUserMedia({
          video: videoConstraints,
          audio: false,
        });
        hasAudio = false;
      }

      // Success
      break;
    } catch (err: any) {
      const errorName = err?.name || '';
      const isBusyError = errorName === 'NotReadableError' || errorName === 'TrackStartError' || errorName === 'AbortError';

      if (isBusyError && retryCount < maxRetries) {
        retryCount++;
        const backoffMs = 200 * Math.pow(2, retryCount); // 400ms, 800ms, 1600ms
        console.warn(`Camera busy (${errorName}), retrying in ${backoffMs}ms (Attempt ${retryCount}/${maxRetries})...`);
        await delay(backoffMs);
      } else {
        // Fallback constraint if high resolution failed
        if (errorName === 'OverconstrainedError' && retryCount < maxRetries) {
          retryCount++;
          console.warn('OverconstrainedError, retrying with default video constraints...');
          try {
            newStream = await navigator.mediaDevices.getUserMedia({
              video: { facingMode },
              audio: mode === 'video',
            });
            break;
          } catch (fallbackErr) {
            console.error('Fallback camera attempt failed:', fallbackErr);
          }
        }
        throw err;
      }
    }
  }

  if (!newStream) {
    throw new Error('Failed to acquire camera stream after retries');
  }

  // Attach to video element
  videoElement.srcObject = newStream;
  videoElement.setAttribute('playsinline', 'true');
  videoElement.muted = true; // Mute video element to prevent feedback loop

  try {
    await videoElement.play();
  } catch (playErr) {
    console.warn('Auto-play video element warning:', playErr);
  }

  // Check torch capability
  const videoTrack = newStream.getVideoTracks()[0];
  let hasTorch = false;
  if (videoTrack && typeof videoTrack.getCapabilities === 'function') {
    const capabilities = videoTrack.getCapabilities() as any;
    hasTorch = !!capabilities?.torch;
  }

  return {
    stream: newStream,
    hasAudio,
    hasTorch,
  };
}

/**
 * Toggles torch mode on video track if available
 */
export async function toggleTorch(stream: MediaStream | null, enable: boolean): Promise<boolean> {
  if (!stream) return false;
  const videoTrack = stream.getVideoTracks()[0];
  if (!videoTrack) return false;

  try {
    const capabilities = typeof videoTrack.getCapabilities === 'function' ? (videoTrack.getCapabilities() as any) : {};
    if (capabilities.torch) {
      await videoTrack.applyConstraints({
        advanced: [{ torch: enable } as any],
      });
      return enable;
    }
  } catch (err) {
    console.warn('Torch constraint toggle error:', err);
  }
  return false;
}
