import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { MediaItem } from '../types';

const GALLERY_INDEX_KEY = 'gps_map_camera_gallery_index';
const FOLDER_NAME = 'GPS_Map_Camera';
const TARGET_DIR = (Directory.Documents || 'DOCUMENTS') as Directory;

/**
 * Synthesizes a crisp camera mechanical shutter click using Web Audio API
 */
export function playShutterSound(): void {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();

    // Noise buffer for mechanical click
    const bufferSize = ctx.sampleRate * 0.05; // 50ms buffer
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = buffer;

    // Filter noise for camera click snap
    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(1000, ctx.currentTime);

    const gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0.6, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.04);

    whiteNoise.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(ctx.destination);

    // Tone pop for shutter mirror click
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(600, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.03);

    oscGain.gain.setValueAtTime(0.4, ctx.currentTime);
    oscGain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.03);

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);

    whiteNoise.start(ctx.currentTime);
    osc.start(ctx.currentTime);

    whiteNoise.stop(ctx.currentTime + 0.05);
    osc.stop(ctx.currentTime + 0.04);
  } catch (err) {
    console.warn('Audio synthesis shutter sound error:', err);
  }
}

/**
 * Ensures target directory exists on Capacitor Filesystem
 */
async function ensureDirectory(): Promise<void> {
  try {
    await Filesystem.mkdir({
      path: FOLDER_NAME,
      directory: TARGET_DIR,
      recursive: true,
    });
  } catch (e) {
    // Ignore if directory already exists
  }
}

/**
 * Saves a photo or video to Android Public Storage (Pictures/GPS_Map_Camera) and local index
 */
export async function saveMediaItem(
  type: 'photo' | 'video',
  dataUrlOrBlob: string | Blob,
  metadata: { lat: number; lng: number; address: string; duration?: number }
): Promise<MediaItem> {
  const timestamp = Date.now();
  const filename = `GPS_CAM_${timestamp}.${type === 'photo' ? 'jpg' : 'mp4'}`;
  let base64Data = '';
  let finalUri = '';

  if (typeof dataUrlOrBlob === 'string') {
    finalUri = dataUrlOrBlob;
    base64Data = dataUrlOrBlob.includes('base64,') ? dataUrlOrBlob.split('base64,')[1] : dataUrlOrBlob;
  } else {
    // Blob handling
    finalUri = URL.createObjectURL(dataUrlOrBlob);
    base64Data = await blobToBase64(dataUrlOrBlob);
  }

  let savedFilePath = '';
  try {
    await ensureDirectory();
    const saveResult = await Filesystem.writeFile({
      path: `${FOLDER_NAME}/${filename}`,
      data: base64Data,
      directory: TARGET_DIR,
    });
    savedFilePath = saveResult.uri;
  } catch (fsErr) {
    console.warn('Capacitor Filesystem write warning (Web fallback active):', fsErr);
  }

  const newItem: MediaItem = {
    id: `item_${timestamp}_${Math.random().toString(36).substring(2, 7)}`,
    type,
    uri: finalUri,
    filePath: savedFilePath || `${FOLDER_NAME}/${filename}`,
    name: filename,
    timestamp,
    size: Math.round(base64Data.length * 0.75),
    lat: metadata.lat,
    lng: metadata.lng,
    address: metadata.address,
    duration: metadata.duration,
  };

  // Update gallery list index in storage
  await addToGalleryIndex(newItem);

  return newItem;
}

/**
 * Helper to convert Blob to Base64 string
 */
function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const res = reader.result as string;
      const base64 = res.includes('base64,') ? res.split('base64,')[1] : res;
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Reads local gallery index and syncs with Capacitor Filesystem if possible
 */
export async function getSavedMediaItems(): Promise<MediaItem[]> {
  let localItems: MediaItem[] = [];

  try {
    const raw = localStorage.getItem(GALLERY_INDEX_KEY);
    if (raw) {
      localItems = JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error reading gallery index:', e);
  }

  // Attempt to scan Capacitor Filesystem directory if available
  try {
    const dirResult = await Filesystem.readdir({
      path: FOLDER_NAME,
      directory: TARGET_DIR,
    });

    if (dirResult && dirResult.files) {
      console.log(`Scanned ${dirResult.files.length} media files in ${FOLDER_NAME}`);
    }
  } catch (capErr) {
    // Normal in web mode
  }

  // Sort newest first
  return localItems.sort((a, b) => b.timestamp - a.timestamp);
}

/**
 * Adds a new item to gallery index
 */
async function addToGalleryIndex(item: MediaItem): Promise<void> {
  const current = await getSavedMediaItems();
  const updated = [item, ...current];
  try {
    localStorage.setItem(GALLERY_INDEX_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Error writing gallery index:', e);
  }
}

/**
 * Deletes a media item from filesystem and gallery index
 */
export async function deleteMediaItem(id: string): Promise<MediaItem[]> {
  const items = await getSavedMediaItems();
  const target = items.find((i) => i.id === id);

  if (target) {
    try {
      await Filesystem.deleteFile({
        path: target.filePath || `${FOLDER_NAME}/${target.name}`,
        directory: TARGET_DIR,
      });
    } catch (fsErr) {
      console.warn('Filesystem delete warning:', fsErr);
    }
  }

  const updated = items.filter((i) => i.id !== id);
  try {
    localStorage.setItem(GALLERY_INDEX_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Error updating gallery index after delete:', e);
  }

  return updated;
}

/**
 * Clears app cache / gallery
 */
export async function clearMediaGallery(): Promise<void> {
  try {
    await Filesystem.rmdir({
      path: FOLDER_NAME,
      directory: TARGET_DIR,
      recursive: true,
    });
  } catch (e) {
    // ignore
  }
  localStorage.removeItem(GALLERY_INDEX_KEY);
}
