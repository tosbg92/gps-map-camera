import { Preferences } from '@capacitor/preferences';
import { StampSettings } from '../types';

export const DEFAULT_SETTINGS: StampSettings = {
  brandingTitle: '',
  brandingTagline: '',
  mapType: 'standard',
  zoomLevel: 16,
  showMapTile: true,
  showLatLng: true,
  showAltitude: true,
  showAddress: true,
  showDateTime: true,
  showWeather: true,
  showCompass: true,
  altitudeUnit: 'm',
  tempUnit: 'C',
  shutterSound: true,

  photoResolution: '1080p',
  videoResolution: '1080p',
  stampSize: 'medium',
  stampPosition: 'bottom-left',
  fontSizeScale: 1.0,
  fontWeight: 'bold',
  textColor: 'emerald',
  backgroundOpacity: 0.85,
};

const SETTINGS_KEY = 'gps_camera_settings';

export async function loadSettings(): Promise<StampSettings> {
  try {
    const { value } = await Preferences.get({ key: SETTINGS_KEY });
    if (value) {
      const parsed = JSON.parse(value);
      return { ...DEFAULT_SETTINGS, ...parsed };
    }
  } catch (err) {
    console.warn('Failed to load settings from Preferences, checking localStorage:', err);
  }

  try {
    const local = localStorage.getItem(SETTINGS_KEY);
    if (local) {
      const parsed = JSON.parse(local);
      return { ...DEFAULT_SETTINGS, ...parsed };
    }
  } catch (e) {
    console.error('LocalStorage fallback error:', e);
  }

  return { ...DEFAULT_SETTINGS };
}

export async function saveSettings(settings: StampSettings): Promise<void> {
  const json = JSON.stringify(settings);
  try {
    await Preferences.set({ key: SETTINGS_KEY, value: json });
  } catch (err) {
    console.warn('Preferences save error:', err);
  }
  try {
    localStorage.setItem(SETTINGS_KEY, json);
  } catch (e) {
    console.error('LocalStorage save error:', e);
  }
}

export async function resetSettings(): Promise<StampSettings> {
  await saveSettings(DEFAULT_SETTINGS);
  return { ...DEFAULT_SETTINGS };
}
