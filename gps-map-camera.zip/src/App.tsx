/**
 * @license
 * Apache-2.0
 * GPS Map Camera - Production App
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { CameraMode, FlashMode, GPSData, MediaItem, StampSettings } from './types';
import { DEFAULT_SETTINGS, loadSettings, resetSettings, saveSettings } from './utils/storage';
import { startCameraStream, stopCameraStream, toggleTorch } from './utils/camera';
import { createStampedPhoto, drawSynchronousStampOverlay, getMapTileUrl, loadImage } from './utils/stamp';
import { playShutterSound, saveMediaItem, getSavedMediaItems, deleteMediaItem, clearMediaGallery } from './utils/mediaSave';
import { watchGPSLocation } from './utils/geolocation';

import { LiveStampOverlay } from './components/LiveStampOverlay';
import { BottomDock } from './components/BottomDock';
import { SettingsDrawer } from './components/SettingsDrawer';
import { GalleryModal } from './components/GalleryModal';

export default function App() {
  // Video element ref
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // App Settings state
  const [settings, setSettings] = useState<StampSettings>(DEFAULT_SETTINGS);
  const settingsRef = useRef<StampSettings>(DEFAULT_SETTINGS);
  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  // Camera state
  const [mode, setMode] = useState<CameraMode>('photo');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [flashMode, setFlashMode] = useState<FlashMode>('off');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [hasTorch, setHasTorch] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [flashTriggered, setFlashTriggered] = useState<boolean>(false);

  // Video Recording state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingTime, setRecordingTime] = useState<number>(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const cachedMapTileRef = useRef<HTMLImageElement | null>(null);

  // GPS Location state
  const [gps, setGps] = useState<GPSData>({
    lat: 28.04712,
    lng: 80.30821,
    accuracy: 4,
    altitude: 155,
    heading: 185,
    speed: 0,
    address: 'SME Govt. ITI, Mohammadi, Lakhimpur Kheri, UP 262804',
    weather: { tempC: 31, tempF: 88, condition: 'Clear Sky' },
    status: 'active',
    timestamp: Date.now(),
  });
  const gpsRef = useRef<GPSData>(gps);
  useEffect(() => {
    gpsRef.current = gps;
  }, [gps]);

  // Pre-cache Map Tile image for synchronous video frame stamping
  useEffect(() => {
    if (settings.showMapTile && gps.lat && gps.lng) {
      const url = getMapTileUrl(gps.lat, gps.lng, settings.zoomLevel, settings.mapType);
      loadImage(url)
        .then((img) => {
          cachedMapTileRef.current = img;
        })
        .catch(() => {
          cachedMapTileRef.current = null;
        });
    }
  }, [gps.lat, gps.lng, settings.zoomLevel, settings.mapType, settings.showMapTile]);

  // Gallery state
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [isGalleryOpen, setIsGalleryOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Load initial settings and saved media
  useEffect(() => {
    async function init() {
      const loadedSettings = await loadSettings();
      setSettings(loadedSettings);
      const items = await getSavedMediaItems();
      setMediaItems(items);
    }
    init();
  }, []);

  // Initialize GPS Watcher
  useEffect(() => {
    const stopWatch = watchGPSLocation((updatedGPS) => {
      setGps(updatedGPS);
    });
    return () => stopWatch();
  }, []);

  // Initialize or Switch Camera Stream
  const initCamera = useCallback(async () => {
    if (!videoRef.current) return;

    setCameraError(null);
    try {
      const resolution = mode === 'photo' ? settings.photoResolution : settings.videoResolution;
      const result = await startCameraStream({
        facingMode,
        mode,
        resolution,
        videoElement: videoRef.current,
        currentStream: cameraStream,
      });

      setCameraStream(result.stream);
      setHasTorch(result.hasTorch);

      // Reset torch state if flash was active
      if (flashMode === 'torch' && result.hasTorch) {
        await toggleTorch(result.stream, true);
      }
    } catch (err: any) {
      console.error('Camera initialization error:', err);
      setCameraError(err?.message || 'Unable to access camera hardware.');
    }
  }, [facingMode, mode, flashMode, cameraStream, settings.photoResolution, settings.videoResolution]);

  // Handle camera stream lifecycle on mode or facingMode changes
  useEffect(() => {
    initCamera();

    return () => {
      stopCameraStream(cameraStream, videoRef.current);
    };
  }, [facingMode, mode]);

  // Flash / Torch Toggle Handler
  const handleToggleFlash = async () => {
    let nextFlash: FlashMode = 'off';
    if (flashMode === 'off') nextFlash = 'on';
    else if (flashMode === 'on') nextFlash = hasTorch ? 'torch' : 'off';
    else nextFlash = 'off';

    setFlashMode(nextFlash);

    if (cameraStream && hasTorch) {
      await toggleTorch(cameraStream, nextFlash === 'torch');
    }
  };

  // Flip Front/Rear Camera Handler
  const handleFlipCamera = () => {
    if (isRecording) return; // Prevent flip during recording
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Photo Capture Action
  const handleTakePhoto = async () => {
    if (!videoRef.current) return;

    // Visual Flash Feedback
    setFlashTriggered(true);
    setTimeout(() => setFlashTriggered(false), 200);

    // Shutter Sound
    if (settings.shutterSound) {
      playShutterSound();
    }

    try {
      // Generate stamped photo canvas Data URL
      const stampedDataUrl = await createStampedPhoto(videoRef.current, gps, settings);

      // Save item to public directory & storage
      const savedItem = await saveMediaItem('photo', stampedDataUrl, {
        lat: gps.lat,
        lng: gps.lng,
        address: gps.address,
      });

      setMediaItems((prev) => [savedItem, ...prev]);
    } catch (err) {
      console.error('Error creating stamped photo:', err);
    }
  };

  // Start Video Recording with Stamped Canvas Stream
  const startRecording = () => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    recordedChunksRef.current = [];
    try {
      // Create hidden offscreen canvas to render video frames + live GPS stamp
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = videoEl.videoWidth || 1280;
      const height = videoEl.videoHeight || 720;
      canvas.width = width;
      canvas.height = height;

      // Continuous render loop at ~30 FPS burning stamp onto video frames
      const renderLoop = () => {
        if (videoEl.readyState >= 2) {
          ctx.drawImage(videoEl, 0, 0, width, height);
          drawSynchronousStampOverlay(
            ctx,
            width,
            height,
            gpsRef.current,
            settingsRef.current,
            cachedMapTileRef.current
          );
        }
        animFrameRef.current = requestAnimationFrame(renderLoop);
      };

      renderLoop();

      // Capture 30FPS Stream from stamped Canvas
      const canvasStream = canvas.captureStream(30);

      // Attach audio tracks from camera stream if available
      if (cameraStream) {
        cameraStream.getAudioTracks().forEach((track) => {
          canvasStream.addTrack(track);
        });
      }

      const options = { mimeType: 'video/webm;codecs=vp8,opus' };
      let mediaRecorder: MediaRecorder;

      if (MediaRecorder.isTypeSupported(options.mimeType)) {
        mediaRecorder = new MediaRecorder(canvasStream, options);
      } else {
        mediaRecorder = new MediaRecorder(canvasStream);
      }

      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        if (animFrameRef.current !== null) {
          cancelAnimationFrame(animFrameRef.current);
          animFrameRef.current = null;
        }

        const videoBlob = new Blob(recordedChunksRef.current, { type: 'video/mp4' });
        const savedItem = await saveMediaItem('video', videoBlob, {
          lat: gps.lat,
          lng: gps.lng,
          address: gps.address,
          duration: recordingTime,
        });

        setMediaItems((prev) => [savedItem, ...prev]);
        setRecordingTime(0);
      };

      mediaRecorder.start(1000); // Record in 1s chunks
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);

      // Timer
      setRecordingTime(0);
      recordTimerRef.current = window.setInterval(() => {
        setRecordingTime((t) => t + 1);
      }, 1000);
    } catch (recErr) {
      console.error('Failed to start MediaRecorder:', recErr);
    }
  };

  // Stop Video Recording
  const stopRecording = () => {
    if (animFrameRef.current !== null) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }

    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (recordTimerRef.current !== null) {
        clearInterval(recordTimerRef.current);
        recordTimerRef.current = null;
      }
    }
  };

  // Shutter Press Dispatcher
  const handleShutterPress = () => {
    if (mode === 'photo') {
      handleTakePhoto();
    } else {
      if (isRecording) {
        stopRecording();
      } else {
        startRecording();
      }
    }
  };

  // Save Settings Handler
  const handleUpdateSettings = async (newSettings: StampSettings) => {
    setSettings(newSettings);
    await saveSettings(newSettings);
  };

  // Reset Settings
  const handleResetSettings = async () => {
    const res = await resetSettings();
    setSettings(res);
  };

  // Clear App Cache / Gallery
  const handleClearCache = async () => {
    if (window.confirm('Are you sure you want to clear all app gallery media?')) {
      await clearMediaGallery();
      setMediaItems([]);
    }
  };

  // Delete Media Item
  const handleDeleteMediaItem = async (id: string) => {
    const updated = await deleteMediaItem(id);
    setMediaItems(updated);
  };

  const lastMediaItem = mediaItems.length > 0 ? mediaItems[0] : null;

  return (
    <div className="relative w-full h-screen bg-slate-950 overflow-hidden select-none font-sans">
      {/* Visual Flash Overlay Effect */}
      {flashTriggered && (
        <div className="absolute inset-0 z-40 bg-white opacity-80 transition-opacity duration-150 pointer-events-none" />
      )}

      {/* Live Fullscreen Video Viewport */}
      <div className="relative w-full h-full bg-slate-950 flex items-center justify-center">
        {cameraError ? (
          <div className="text-center p-6 bg-slate-900 border border-slate-800 rounded-2xl max-w-sm m-4 z-10 text-slate-300 space-y-3">
            <p className="font-bold text-rose-400 text-base">Camera Hardware Lock or Permission Needed</p>
            <p className="text-xs text-slate-400 leading-relaxed">{cameraError}</p>
            <button
              onClick={() => initCamera()}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-colors"
            >
              Retry Camera Connection
            </button>
          </div>
        ) : (
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        )}

        {/* Live Glassmorphic Stamp Box Overlay (Bottom-Left) */}
        {!cameraError && <LiveStampOverlay gps={gps} settings={settings} />}
      </div>

      {/* Bottom Dock Controls */}
      <BottomDock
        mode={mode}
        flashMode={flashMode}
        onChangeMode={setMode}
        onShutterPress={handleShutterPress}
        onFlipCamera={handleFlipCamera}
        onToggleFlash={handleToggleFlash}
        onOpenGallery={() => setIsGalleryOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        lastMediaItem={lastMediaItem}
        totalMediaCount={mediaItems.length}
        isRecording={isRecording}
        recordingTime={recordingTime}
      />

      {/* Slide-over Settings Drawer */}
      <SettingsDrawer
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onResetSettings={handleResetSettings}
        onClearCache={handleClearCache}
      />

      {/* In-App Gallery Modal */}
      <GalleryModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        items={mediaItems}
        onDeleteItem={handleDeleteMediaItem}
      />
    </div>
  );
}
